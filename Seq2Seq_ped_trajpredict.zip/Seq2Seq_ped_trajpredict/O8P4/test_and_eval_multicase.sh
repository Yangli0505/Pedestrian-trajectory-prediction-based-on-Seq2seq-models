#!/usr/bin/env bash

k_folds=4
select_epoch=(115 75 95 90)
scenario_class=2
eval_res_file="scenario_2_res.txt"

for k in $(seq $k_folds) 
do 
    let k=k-1

	
    let epoch=${select_epoch[k]}
    echo "*****************This is fold ${k} with epoch ${epoch}***************"
    saving_path="save${k}"

    model_checkpoint=`ls $saving_path/epoch_${epoch}_model.ckpt*.index`
    
    if [ -z ${model_checkpoint} ];then
        echo "models at epoch ${epoch} have not been generated!"
        continue
    fi
    
	eval_tmp='tmp_eval_res.txt'
	eval_res_cache="${eval_res_file}"


    python test_and_eval_MultiCASE.py \
        --epoch ${epoch} \
        --saving_path ${saving_path} \
        --model_checkpoint ${model_checkpoint} \
        --scenario_class ${scenario_class} \
        --scenario_res ${eval_tmp}
    cat $eval_tmp >> $eval_res_cache   


done

#python read_scenario_res.py \
#    --file ${eval_res_file}
