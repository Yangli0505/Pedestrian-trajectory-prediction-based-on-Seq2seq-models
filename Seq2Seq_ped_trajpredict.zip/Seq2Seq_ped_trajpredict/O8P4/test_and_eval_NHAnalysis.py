# -*- coding: utf-8 -*-
"""
Created on Thu Oct  4 10:25:23 2018

@author: yang
"""


import pickle
import os
import argparse
import tensorflow as tf
import numpy as np
import shutil
from seq2seq_model import Model


import scipy.io
from Test_NewDataloader_plus_x import Dataloader




def get_absolute_trajectory(traj):
    '''
    Function that computes the absolute coordinates of the trajectory
    traj: (10,7)
    '''
    new_traj=np.zeros([len(traj),1])
    
    for i in range(len(traj)):
         
        real_lat=traj[i,0]*(traj[i,1]-traj[i,2])+traj[i,2]  # lat        
        new_traj[i,0]=real_lat

    return new_traj
    


def get_mean_lat_error(predicted_traj, true_traj, observed_length):
    # The data structure to store all errors
    error = np.zeros(len(true_traj) - observed_length)
    # For each point in the predicted part of the trajectory
    for i in range(observed_length, len(true_traj)):
        # The predicted position
        pred_pos = predicted_traj[i, 0:1]
        # The true position
        true_pos = true_traj[i, 0:1]

        # The euclidean distance is the error
        error[i-observed_length] = np.linalg.norm(true_pos - pred_pos)

    return np.mean(error)


    
def get_NH_case(NH_case):
    
    case=[]
    
    if NH_case==1:        # stop-normal
        case=[3,11,18,19,20]
        
    elif NH_case==2:      # stop-hard
        case=[21,39,44,45,47]
        
    elif NH_case==3:      # cross-normal
        case=[24,26,33,34,40,41,43,1,7,8,9,10,14,16,17,29,30,25,27,28,49,52,2,31,32,54,56,57,42] #28
        
    else:                 # cross-hard
        case=[5,4,6,12,42,13,35,36,53,23,15,55] #13
    
    return case
        

# ----------------------------------------basic parameters----------------------------#
parser=argparse.ArgumentParser()
parser.add_argument('--obs_length',type=int,default=8, help='Observed length of the trajectory')
                    
parser.add_argument('--pred_length',type=int,default=4, help='Predicted length of the trajectory')

parser.add_argument('--seq_length',type=int,default=12, help='Number of test cases')

parser.add_argument('--seq_interval', type=int, default=1,
                    help='time interval when picking up sequences')
                         

parser.add_argument('--model_checkpoint', type=str, default=None,
                    help='model checkpoint')
                    
parser.add_argument('--saving_path', type=str, default=None,
                    help='saving path')
                    
parser.add_argument('--epoch', type=str, default=None,
                    help='epoch')


parser.add_argument('--NH_case', type=int, default=1, help='NH_case={1,2,3,4}')
                    
args=parser.parse_args()



if __name__ == '__main__':

    #-------------------------------------- parameters setting----------------------#
    print("args:",args)
    #  original
    model_checkpoint = args.model_checkpoint
    model_checkpoint = model_checkpoint[:-6] # eg. epoch_2_model.ckpt-196.index -> eg. epoch_2_model.ckpt-196
    print("model_checkpoint:", model_checkpoint)

    saving_path =args.saving_path
    epoch = args.epoch
    with open(os.path.join(saving_path, 'config.pkl'), 'rb') as fid: 
        saved_args = pickle.load(fid)
        
    #------------------ model setting ----------------#
    tf.reset_default_graph()
    rnn_model_test = Model(saved_args, feed_previous=True)    
    sess = tf.InteractiveSession() #Initialize TensorFlow session
    
    sess.run(tf.global_variables_initializer())    
    saver = rnn_model_test.saver.restore(sess, model_checkpoint)

    #------------------------------------Loading test cases ------------------------------#
     
    
    test_case=get_NH_case(args.NH_case)
    print('test_case',test_case)

    test_Dataloader=Dataloader(test_case,args.obs_length,args.seq_length, args.seq_interval)
    
    INPUT_test=test_Dataloader.X #[,8,3]
    OUTPUT_test=test_Dataloader.Y
    
    print('INPUT_test',np.shape(INPUT_test)) 
    print('OUTPUT_test',np.shape(OUTPUT_test))
    INPUT_test=np.array(INPUT_test)
    OUTPUT_test=np.array(OUTPUT_test)
    
    
    test_input1=INPUT_test[:,:,0:1]
    test_output1=OUTPUT_test[:,:,0:1]
    
    test_input2=test_input1[:,:,0] #[,obs_len]
    test_output2=test_output1[:,:,0]   #[,pre_len]

    # test errors         

    lat_error_inv=0.0
    lat_error_inv_fp=0.0

    error_each_inv_lat=0.0
    error_each_inv_lat_fp=0.0


   #-----------------------one by one------------------#    
    for j in range(len(INPUT_test)):
        
        test_seq_input_1=test_input2[j]
        test_seq_output_1=test_output2[j]
        
        feed_dict = {rnn_model_test.enc_inp[t]: test_seq_input_1[t].reshape(1, 1) for t in range(saved_args.obs_length)}
        feed_dict.update({rnn_model_test.target_seq[t]: np.zeros([1, saved_args.output_dim], dtype=np.float32) for t in range(saved_args.pred_length)})
        final_preds = sess.run(rnn_model_test.reshaped_outputs, feed_dict)
        final_preds = np.concatenate(final_preds, axis = 1)
        final_preds=final_preds.reshape(-1)
        
        #-----------------error with inverse-normalization---------------#
        
        temp_input0=np.reshape(INPUT_test[j,:,:],[-1,4]) # [,3]
        temp_output0=np.reshape(OUTPUT_test[j,:,:],[-1,4]) #[,3]
    
        # get the oringinal trajectory
        
        pred_gt_traj_inv=get_absolute_trajectory(temp_output0) # only prediction part-GT

        temp_final_preds=np.c_[np.reshape(final_preds,[-1,1]),temp_output0[:,1:4]] #[8,3]
        
        pred_traj_inv=get_absolute_trajectory(temp_final_preds)  # only prediction part-Prediction
        
        lat_error_inv+=get_mean_lat_error(pred_gt_traj_inv, pred_traj_inv, 0)
        lat_error_inv_fp+=get_mean_lat_error(pred_gt_traj_inv, pred_traj_inv, saved_args.pred_length-1)
        
        
       
    error_each_lat_inv=lat_error_inv/INPUT_test.shape[0] # lat
    error_each_lat_inv_fp=lat_error_inv_fp/INPUT_test.shape[0] # final points pf the lat
  

    
    result_str= epoch+","+str(error_each_lat_inv)+","+str(error_each_lat_inv_fp)+'\n'
    print('result of NH_case',result_str)
    result_file=os.path.join(saving_path,'NH_case_'+str(args.NH_case)+'.txt')
#    result_path='./'+result_file
#    
#    if os.path.exists(result_path):
#        os.remove(result_path)

    with open(result_file,'w') as fid:
        fid.write(result_str)   
    


