# -*- coding: utf-8 -*-
"""
Created on Tue Sep 25 11:47:29 2018
This is to calculate the mean error of 4 folds
@author: yang
"""
import numpy as np
import os

eval_res_all=[]

for k in range(4):
    
    data=[]
    savingpath='save'+str(k)
    resultfile='eval_res.txt'
    resultpath=os.path.join(savingpath,resultfile)    
    data=np.loadtxt(resultpath,delimiter=',')
    eval_res_all.append(data)
    
A=eval_res_all[0]
B=eval_res_all[1]
C=eval_res_all[2]
D=eval_res_all[3]


lat_error_each_inv=(min(A[:,1])+min(B[:,1])+min(C[:,1])+min(D[:,1]))/4
lat_error_each_inv_fp=(min(A[:,2])+min(B[:,2])+min(C[:,2])+min(D[:,2]))/4


print('mean error-lat traj:{}'.format(lat_error_each_inv))
print('mean error-lat traj-final point:{}'.format(lat_error_each_inv_fp))
