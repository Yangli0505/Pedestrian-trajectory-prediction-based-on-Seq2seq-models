# -*- coding: utf-8 -*-
"""
Created on Fri Jan  4 12:14:23 2019

@author: thisv
"""

import pickle
import os
import matplotlib.pyplot as plt
import argparse
import numpy as np

#%%
parser=argparse.ArgumentParser()

parser.add_argument('--obs_length',type=int,default=8, help='Observed length of the trajectory')

parser.add_argument('--pred_length',type=int,default=8, help='Predicted length of the trajectory')

parser.add_argument('--seq_length',type=int,default=16, help='Number of test cases')

parser.add_argument('--test_case_a', type=int, default=26,help='ID of testccase a')
parser.add_argument('--test_case_b', type=int, default=29,help='ID of testccase b')
                    
args=parser.parse_args() 


def get_mean_lat_error(predicted_traj, true_traj, observed_length):
    # The data structure to store all errors
    error = np.zeros(len(true_traj) - observed_length)
    # For each point in the predicted part of the trajectory
    for i in range(observed_length, len(true_traj)):
        # The predicted position
        pred_pos = predicted_traj[i]
        # The true position
        true_pos = true_traj[i]

        # The euclidean distance is the error
        error[i-observed_length] = np.linalg.norm(true_pos - pred_pos)

    return np.mean(error)

#-------------------------start 
lat_error_inv_all=0.0
lat_error_inv_fp_all=0.0

save_contents_a=os.path.join('special_case',str(args.test_case_a)+'.pkl')
save_contents_b=os.path.join('special_case',str(args.test_case_b)+'.pkl')

with open(save_contents_a, 'rb') as fid: 
    allresult_a = pickle.load(fid)
    
with open(save_contents_b, 'rb') as fid: 
    allresult_b = pickle.load(fid)



#-----------------plot the figures--------------------------------#
font1 = {'family' : 'Times New Roman',
'weight' : 'normal',
'size'   : 12,
}

font2 = {'family' : 'Times New Roman',
'weight' : 'normal',
'size'   : 10,
}


plt.figure(figsize=(6,5))

ax1=plt.subplot(1,2,1)

for j in range(len(allresult_a)):
    
    #print('j={}'.format(j))
    
    tem_A=np.reshape(np.array(allresult_a[j]),[-1,16])
#    plt.figure(j)
    
    l11,=plt.plot(tem_A[0,:], tem_A[1,:],color='green')
    
    #l31,=plt.plot(tem_A[0,args.obs_length:args.seq_length],tem_A[2,args.obs_length:args.seq_length],marker='.',color='red')
    l31,=plt.plot(tem_A[0,args.obs_length:args.seq_length],tem_A[2,args.obs_length:args.seq_length],color='red')
    plt.setp(l11, color='b', linewidth=1.5)
    plt.setp(l31, color='r', linewidth=1.0)
   
plt.legend(handles = [l11, l31], labels = ['GT','PT-P'], loc = 'best',prop=font2)
plt.xlabel('(a) Time to event [frame]',font1)
plt.ylabel('Lateral Position [m]',font1)
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)  
plt.title('Normal: Crossing case-'+str(args.test_case_a),font1)
plt.grid()
plt.axis([-20,40,-2,5])


labels = ax1.get_xticklabels() + ax1.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels]


ax2=plt.subplot(1,2,2)

for j in range(len(allresult_b)):

    
    tem_B=np.reshape(np.array(allresult_b[j]),[-1,16])
#    plt.figure(j)
    #l11,=plt.plot(tem_B[0,:], tem_B[1,:],color='green', marker='o')
    l11,=plt.plot(tem_B[0,:], tem_B[1,:],color='green')
    #l21,=plt.plot(tem_A[0,:], tem_A[2,:],marker='x',color='blue')
    #l31,=plt.plot(tem_B[0,args.obs_length:args.seq_length],tem_B[2,args.obs_length:args.seq_length],marker='*',color='red')
    l31,=plt.plot(tem_B[0,args.obs_length:args.seq_length],tem_B[2,args.obs_length:args.seq_length],color='red')
    
    plt.setp(l11, color='b', linewidth=1.5)
    plt.setp(l31, color='r', linewidth=1.0)


    
plt.legend(handles = [l11, l31], labels = ['GT','PT-P'], loc = 'best',prop=font2)
plt.xlabel('(b) Time to event [frame]',font1)
#plt.ylabel('Lateral Position [m]')
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)  
plt.title('Normal: Crossing case-'+str(args.test_case_b),font1)
plt.grid()
plt.axis([-20,50,-2,5])
labels = ax2.get_xticklabels() + ax2.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels]


plt.savefig('normal-cross.png', dpi = 300)

plt.show()
#print('mean lat error',lat_error_inv_all/len(allresult))
#print('mean lat error fp of those trajs',lat_error_inv_fp_all/len(allresult))
plt.close()






