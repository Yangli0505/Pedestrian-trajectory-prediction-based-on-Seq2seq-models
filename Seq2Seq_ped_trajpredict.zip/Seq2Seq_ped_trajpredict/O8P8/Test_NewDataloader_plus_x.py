# -*- coding: utf-8 -*-
"""
Created on Fri Dec 21 16:56:00 2018

@author: DELL
"""


import numpy as np
import xlrd
import math 
import scipy.io


class Dataloader():
    
    def __init__(self,caseID,obs_length,seq_length,delt):
    
        data_file='./Daimler_ECCV14_PedData_Smooth.xlsx'
        trainData=xlrd.open_workbook(data_file)  
        data_file_c='./Daimler_ECCV14_PedData_Smooth_ForCross.xlsx'
        trainData_c=xlrd.open_workbook(data_file_c)
        
        # ---------------------------pick up train data----------------------------------------
        X=[]
        Y=[]
        
        temp_s=scipy.io.loadmat('c4.mat')
        stop_case=np.array(temp_s['C4']) 
        
        
        for i in range(len(caseID)): 
                    
            # find the max and min lateral position for normalization
            [max_temp,min_temp]=[0.0,0.0]
            
            if caseID[i] in stop_case:
                
                
                #print('this is the stop case!')
            #if caseID[i]==22 or caseID[i]==48 or caseID[i]==18 or caseID[i]==19:
                if caseID[i]==22 or caseID[i]==48:
                    continue
                
                sheet=trainData.sheet_by_index(caseID[i]-1) 
                
                print('sheet.nrows',sheet.nrows)
                
                if sheet.nrows<=2*seq_length-1:
                    continue
	           
	                

                for p in range(sheet.nrows): 
                    
                    ped_lat_o=sheet.row_values(p)[2] # original lateral position
                    ped_lat_o=np.array(ped_lat_o)
                    
                    ped_lat_s=sheet.row_values(p)[26:85]
                    ped_lat_s=np.array(ped_lat_s)
                    
                    ped_lat_t=sheet.row_values(p)[87:102]
                    ped_lat_t=np.array(ped_lat_t)
                    
                    ped_lat_a=np.r_[np.r_[[ped_lat_o],ped_lat_s],ped_lat_t]
                    
                    if ped_lat_a.max()>max_temp:
                        max_temp=ped_lat_a.max()
                        
                    if ped_lat_a.min()<min_temp:
                        min_temp=ped_lat_a.min()
                        
                lat_max=math.ceil(max_temp)
                lat_min=math.floor(min_temp)
                
                j=0
                while j<=sheet.nrows-2*seq_length:
                    
                    #count=0
                    for ig in range(25,26):
                        if ig==86:
                            continue
                        # observation part                        
                        #count=count+1
                        observationSeqs=[]
                        for n in range(obs_length):
                            
                            n=2*n
                            posLat1=(sheet.row_values(j+n)[ig]-lat_min)/(lat_max-lat_min)
                            tte1=sheet.row_values(j+n)[1]
                            observationSeqs.append([posLat1,lat_max,lat_min,tte1]) 
                        
                        X.append(observationSeqs)
                        
                        # prediction part
                        predictionSeqs=[]    
                        for m in range(obs_length,seq_length):                        
                        
                            m=2*m
                            posLat2=(sheet.row_values(j+m)[ig]-lat_min)/(lat_max-lat_min)  
                            tte2=sheet.row_values(j+m)[1]
                            predictionSeqs.append([posLat2,lat_max,lat_min,tte2])   
                                
                        Y.append(predictionSeqs)
                                            
                    j+=delt
                    
                
            else:
                
                #print('this is the cross case!')
                
                sheet=trainData_c.sheet_by_index(caseID[i]-1) 
                if sheet.nrows<=2*seq_length-1:
                    continue
                
                for p in range(sheet.nrows):  
                    
                                        
                    ped_lat_o=sheet.row_values(p)[2] # original lateral position
                    ped_lat_o=np.array(ped_lat_o)                    
    
                    ped_lat_s=sheet.row_values(p)[26:38]
                    ped_lat_s=np.array(ped_lat_s)
                                        
                    ped_lat_t=sheet.row_values(p)[39:45]
                    ped_lat_t=np.array(ped_lat_t)                
                    
                    
                    ped_lat_r=sheet.row_values(p)[46:50]
                    ped_lat_r=np.array(ped_lat_r)

                    ped_lat_z=sheet.row_values(p)[51:63]
                    ped_lat_z=np.array(ped_lat_z)
                                                            
                    ped_lat_a=np.r_[np.r_[np.r_[np.r_[[ped_lat_o],ped_lat_s],ped_lat_t],ped_lat_r],ped_lat_z]
                    
                    
                    if ped_lat_a.max()>max_temp:
                        max_temp=ped_lat_a.max()
                        
                    if ped_lat_a.min()<min_temp:
                        min_temp=ped_lat_a.min()
                            
                lat_max=math.ceil(max_temp)
                lat_min=math.floor(min_temp)
                
                j=0
                
                while j<=sheet.nrows-2*seq_length:
                    
                    count=0
                    
                    for ig in range(25,26):  
                        if ig==38 or ig==45 or ig==50:
                            continue
                        # observation part                        
                        count=count+1
                        observationSeqs=[]
                        for n in range(obs_length):
                            
                            n=2*n
                            posLat1=(sheet.row_values(j+n)[ig]-lat_min)/(lat_max-lat_min)
                            tte1=sheet.row_values(j+n)[1]
                            observationSeqs.append([posLat1,lat_max,lat_min,tte1]) 
                        
                        X.append(observationSeqs)
                        
                        # prediction part
                        predictionSeqs=[]    
                        for m in range(obs_length,seq_length):                        
                        
                            m=2*m
                            posLat2=(sheet.row_values(j+m)[ig]-lat_min)/(lat_max-lat_min)
                            tte2=sheet.row_values(j+m)[1]  
                            predictionSeqs.append([posLat2,lat_max,lat_min,tte2])   
                                
                        Y.append(predictionSeqs)
                                                
                    #print('count={}'.format(count))
                    j+=delt   
                    
        
        self.X=X
        self.Y=Y
        
        
   
