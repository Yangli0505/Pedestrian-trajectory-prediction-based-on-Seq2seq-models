#!/usr/bin/env bash

k_folds=5
select_epoch=(70 80 75 110 75)
test_case=26

for k in $(seq $k_folds) 
do 
    let k=k-1

	
    let epoch=${select_epoch[k]}
    echo "*****************This is fold ${k} with epoch ${epoch}***************"
    saving_path="save${k}"

    model_checkpoint=`ls $saving_path/epoch_${epoch}_model.ckpt*.index`
    
    if [ -z ${model_checkpoint} ];then
        echo "models at epoch ${epoch} have not been generated!"
        continue
    fi
    
	eval_tmp='tmp_eval_res.txt'
	eval_res_cache="${eval_res_file}"


    python singlecase_test.py \
        --epoch ${epoch} \
        --saving_path ${saving_path} \
        --model_checkpoint ${model_checkpoint} \
        --test_case ${test_case} 

     


done

python singlecase_evaluation.py \
    --test_case ${test_case} 
