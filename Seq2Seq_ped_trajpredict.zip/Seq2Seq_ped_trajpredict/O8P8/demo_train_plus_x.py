# -*- coding: utf-8 -*-
"""
Created on Sat Dec 22 11:21:33 2018

@author: DELL
"""

# Demo to test the new model

from __future__ import division
import tensorflow as tf
import argparse
import numpy as np
import os
import matplotlib.pyplot as plt
from NewDataloader_plus_x import Dataloader
from sklearn.model_selection import KFold
from seq2seq_model import Model
import shutil
import pickle
import random
import time
import scipy.io



def get_data(K):
       
    ##************* Prepare the cross and stop case *******************#
    # cross case
    temp_a=scipy.io.loadmat('c1.mat')
    temp_b=scipy.io.loadmat('c2.mat')
    temp_c=scipy.io.loadmat('c3.mat')
    temp_d=scipy.io.loadmat('c5.mat')
    test_case_a=np.array(temp_a['C1']) 
    test_case_b=np.array(temp_b['C2'])
    test_case_c=np.array(temp_c['C3'])  
    test_case_d=np.array(temp_d['C5']) 
    cross_case=[]
    
    for i in range(len(test_case_a)):
        cross_case.append(test_case_a[i][0])
    for i in range(len(test_case_b)):
        cross_case.append(test_case_b[i][0])
    for i in range(len(test_case_c)):
        cross_case.append(test_case_c[i][0])
    for i in range(len(test_case_d)):
        cross_case.append(test_case_d[i][0])
    print('sum of all cross_case',len(cross_case))
    
    # stop_case
    temp_s=scipy.io.loadmat('c4.mat')
    raw_stop_case=np.array(temp_s['C4'])
    discard_stopcase_index=[6, 13]
    stop_case=np.delete(raw_stop_case,discard_stopcase_index)
    print('sum of all stop_case',len(stop_case))
    
    
    
    # k=5, cross case
    kf=KFold(n_splits=K,shuffle=True) # 5 groups in total
    crosscase_ID=[]    
      
    for train_index, test_index in kf.split(cross_case):
        crosscase_ID.append([train_index,test_index])  #train_crosscase, test_crosscase
    
    # k=5, stop case
    kf=KFold(n_splits=K,shuffle=True) # 5 groups in total
    stopcase_ID=[]   
       
    for train_index, test_index in kf.split(stop_case):
        stopcase_ID.append([train_index,test_index]) 
        
        
    return cross_case,stop_case,crosscase_ID,stopcase_ID

#%% List Model Parameters

parser=argparse.ArgumentParser() 

parser.add_argument('--rnn_size', type=int,default=128, help='size of RNN hidden state')

parser.add_argument('--num_layers', type=int,default=1, help='num of layers in the RNN')

parser.add_argument('--forget_bias', type=float,default=1.0,help='forget bias in the RNN') # keep all

parser.add_argument('--model', type=str,default='lstm', help='rnn, gru, or lstm')

parser.add_argument('--seq_length', type=int, default=16,help='rnn sequence length')

parser.add_argument('--obs_length', type=int, default=8, help='observed rnn sequence length')

parser.add_argument('--pred_length', type=int, default=8,help='predicted rnn sequence length')    

parser.add_argument('--input_dim',type=int,default=1,help='number of input feartures')

parser.add_argument('--output_dim',type=int,default=1,help='number of output features')

parser.add_argument('--batch_size', type=int, default=32, help='minibatch size')

parser.add_argument('--embedding_size', type=int, default=128,help='Embedding dimension for the spatial coordinates')

parser.add_argument('--grad_clip', type=float, default=2.5,help='clip gradients at this value')

parser.add_argument('--learning_rate',type=float, default=0.01,help='learning rate')

parser.add_argument('--decay_rate', type=float, default=0.95, help='decay rate for rmsprop')

parser.add_argument('--num_epoches',type=int, default=121, help='number of epoches')

parser.add_argument('--saving_every_epoch',type=int, default=5, help='save frequency')

parser.add_argument('--seq_interval', type=int, default=1, help='time interval when picking up sequences')

parser.add_argument('--casebatch_size', type=int, default=5,help='case of minibatch size')
                    
parser.add_argument('--keep_prob', type=float, default=0.8, help='dropout keep probability')

parser.add_argument('--lamda_param', type=float, default=0.01,help='L2 regularization parameter')


args=parser.parse_args()

tf.reset_default_graph()

# ......data loading....... 
cross_case,stop_case,crosscase_ID,stopcase_ID=get_data(K=5)

for k in range(5):
    
    print('-------------training of {} folds starts-------------'.format(k))
    
    train_cross=[cross_case[i] for i in crosscase_ID[k][0]]
    train_stop=[stop_case[i] for i in stopcase_ID[k][0]]
    train_case=[]
    train_case=np.r_[train_stop,train_cross]
    test_cross=[cross_case[i] for i in crosscase_ID[k][1]]
    test_stop=[stop_case[i] for i in stopcase_ID[k][1]]
    test_case=[]
    test_case=np.r_[test_stop,test_cross]    
    print('train_case',train_case)
    print('test_case',test_case)
    

    tf.reset_default_graph()
    saving_path='save'+str(k)
    
    if os.path.exists(saving_path):
        shutil.rmtree(saving_path, ignore_errors=True) 
        
    if not os.path.exists(saving_path):
        os.makedirs(saving_path)
    
    with open(os.path.join(saving_path,'config.pkl'),'wb') as f: # mainly used to save the args
        pickle.dump(args,f)
        
    lossinfo_path=os.path.join(saving_path,'training_loss_info.txt')
    if os.path.exists(lossinfo_path):
        os.remove(lossinfo_path)

    
    # Save the test data 
    test_Dataloader=Dataloader(test_case,args.obs_length,args.seq_length, args.seq_interval)


    INPUT_test=test_Dataloader.X
    OUTPUT_test=test_Dataloader.Y  
    print('shape of test data',np.shape(INPUT_test))
    
    test_X_cache = os.path.join(saving_path, 'test_X.pkl')
    test_Y_cache = os.path.join(saving_path, 'test_Y.pkl')
    
    with open(test_X_cache,'wb') as fid:
        pickle.dump(INPUT_test, fid)    
        
    with open(test_Y_cache, 'wb') as fid:
        pickle.dump(OUTPUT_test, fid) 
    
    
    
    print('************************This is  fold {} as the test set, Training begins**********'.format(k))
    print('*************************************')
    
    #%%:Train
    
    rnn_model = Model(args, feed_previous=False)
    temp_saver = rnn_model.saver
    
    train_loss=[]
    
    with tf.Session() as sess:
        
        sess.run(tf.global_variables_initializer())
        
        min_epoch_loss=10.0
        min_epoch=0
        for e in range(args.num_epoches):
            
            epoch_loss=0.0
            st_epoch=time.time()
            sess.run(tf.assign(rnn_model.lr, args.learning_rate * (args.decay_rate ** e)))   
            
            random.shuffle(train_case)
            train_data=Dataloader(train_case,args.obs_length,args.seq_length, args.seq_interval)
            
            train_input=train_data.X
            print('shape of training input',np.shape(train_input))
            
            train_output=train_data.Y
            cc=list(zip(train_input,train_output))
            random.shuffle(cc)
            train_input[:],train_output[:]=zip(*cc)
            
            
            num_batch=len(train_input)//args.batch_size
            
            temp_loss=0.0
            for b in range(1, num_batch+1):
                
                [p, q]=[(b-1)*args.batch_size, b*args.batch_size]
                x1=np.array(train_input[p:q],dtype=np.float32)
                y1=np.array(train_output[p:q],dtype=np.float32)
                [x11,y11]=[x1[:,:,0:1],y1[:,:,0:1]]
                [batch_input,batch_output]=[x11[:,:,0],y11[:,:,0]]
            
                feed_dict = {rnn_model.enc_inp[t]: batch_input[:,t].reshape(-1,args.input_dim) for t in range(args.obs_length)}    
                feed_dict.update({rnn_model.target_seq[t]: batch_output[:,t].reshape(-1,args.output_dim) for t in range(args.pred_length)})    
                
                _, loss_t = sess.run([rnn_model.train_op, rnn_model.loss], feed_dict)
                temp_loss+=loss_t
                
            epoch_loss=temp_loss/num_batch
            if epoch_loss<min_epoch_loss:
                min_epoch_loss=epoch_loss
                min_epoch=e
                
                
                
                
            et_epoch=time.time()
            print('epoch:{}, time used:{}'.format(e,et_epoch-st_epoch))
            
            
            if (e+1) % args.saving_every_epoch == 0:
                print('********************')
                print('epoch:{},epoch loss:{}'.format(e, epoch_loss))
                print('min epoch:{},min epoch loss:{}'.format(min_epoch, min_epoch_loss))
                # save the model
                checkpoint_path=os.path.join(saving_path,'epoch_{}_model.ckpt'.format(e+1))
                result_path=temp_saver.save(sess,checkpoint_path,global_step=(e+1)*num_batch)
                train_loss.append([e+1,epoch_loss])
                np.savetxt(lossinfo_path,[e+1, epoch_loss])
                
                print('********************')
            
            
        
        
#        plt.figure()
#        plt.plot(train_loss[:,0],train_loss[:,1],'r-o')
#        plt.xlabel('Epoch')
#        plt.ylabel('Training Loss')
#        plt.show()
	
 
    print('Train of fold {} Ends'.format(k))
    
    
    
    
    
