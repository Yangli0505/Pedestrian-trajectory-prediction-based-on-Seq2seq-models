#!/usr/bin/env bash

k_folds=5
select_epoch=(70 80 75 110 75)
NH_case=4
#eval_res_file="scenario_1_res.txt"

for k in $(seq $k_folds) 
do 
    let k=k-1

	
    let epoch=${select_epoch[k]}
    echo "*****************This is fold ${k} with epoch ${epoch}***************"
    saving_path="save${k}"

    model_checkpoint=`ls $saving_path/epoch_${epoch}_model.ckpt*.index`
    
    if [ -z ${model_checkpoint} ];then
        echo "models at epoch ${epoch} have not been generated!"
        continue
    fi
    
	#eval_tmp='tmp_eval_res.txt'
	#eval_res_cache="${eval_res_file}"


    python test_and_eval_NHAnalysis.py \
        --epoch ${epoch} \
        --saving_path ${saving_path} \
        --model_checkpoint ${model_checkpoint} \
        --NH_case ${NH_case} 
        
    #cat $eval_tmp >> $eval_res_cache   


done

#python readtxt_NHcase.py \
#    --file ${eval_res_file}
